import { Component } from '@angular/core';

@Component({
  selector: 'app-child-test',
  standalone: false,
  templateUrl: './child-test.html',
  styleUrl: './child-test.css'
})
export class ChildTest {

}
