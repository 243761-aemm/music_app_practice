import { Component } from '@angular/core';

@Component({
  selector: 'app-child-test2',
  standalone: false,
  templateUrl: './child-test2.html',
  styleUrl: './child-test2.css'
})
export class ChildTest2 {

}
