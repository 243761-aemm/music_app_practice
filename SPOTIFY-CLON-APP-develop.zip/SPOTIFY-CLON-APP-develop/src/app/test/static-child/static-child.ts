import { Component } from '@angular/core';

@Component({
  selector: 'app-static-child',
  standalone: false,
  templateUrl: './static-child.html',
  styleUrl: './static-child.css'
})
export class StaticChild {

}
