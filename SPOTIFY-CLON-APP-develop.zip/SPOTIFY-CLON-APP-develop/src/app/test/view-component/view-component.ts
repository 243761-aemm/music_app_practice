import { Component } from '@angular/core';

@Component({
  selector: 'app-view-component',
  standalone: false,
  templateUrl: './view-component.html',
  styleUrl: './view-component.css'
})
export class ViewComponent {

}
