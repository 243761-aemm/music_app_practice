export interface Image {
    width: number,
    heigth: number,
    url: string
}
