export interface Song {

    cover: string,
    artist: string,
    name: string

}
