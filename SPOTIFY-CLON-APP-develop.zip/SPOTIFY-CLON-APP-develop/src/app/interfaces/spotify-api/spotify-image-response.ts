export interface SpotifyImageResponse {

    width: number,
    heigth: number,
    url: string
    
}
